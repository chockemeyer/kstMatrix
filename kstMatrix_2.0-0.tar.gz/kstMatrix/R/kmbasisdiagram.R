#' DEPRECATED: Plot the Hasse diagram of a basis stored as a matrix
#'
#' \code{kmbasisdiagram} takes a matrix representing a basis and a
#' color vector and draws a Hasse diagram. If the color vector is NULL
#' the states are drawn in orange.
#'
#' Deprecaed - please use the \code{plot()} method instead!
#'
#' @param struc Binary matrix representing a basis
#' @param horizontal Boolean defining orientation of the graph, default TRUE
#' @param colors Color value or vector (default NULL)
#' @param keepNames Keep item names (default FALSE)
#' @param itemsep Item separator in sets (default '')
#' @param braces Put braces around vertices (default FALSE)
#' @param vertexsize Size of the vertex circles, "fixed" (default) or "variable"
#'
#' @family Deprecated plotting functions
#'
#' @importFrom igraph graph E V plot.igraph add_shape shapes
#' @importFrom plotrix draw.ellipse
#'
#' @export
kmbasisdiagram <- function(struc,
                           horizontal = TRUE,
                           colors=NULL,
                           keepNames = FALSE,
                           itemsep = '',
                           braces = FALSE,
                           vertexsize = "fixed"
){
  # The ellipse xode was adapted from a stackoverflow posting.
  myellipse <- function(coords, v=NULL, params){
    vertex.size <- params("vertex", "size")/100
    vertex.color <- params("vertex", "color")
    draw.ellipse(x=coords[,1],
                 y=coords[,2],
                 a=vertex.size,
                 b=vertex.size/2,
                 col=vertex.color
                 )
  }
  add_shape("ellipse",
            clip=shapes("circle")$clip,
            plot=myellipse)


  warning("Use of the function 'kmbasisdiagram()' is deprecated - please use the 'plot()' method instead.")
  structure <- t(struc)
  if (!requireNamespace("igraph", quietly = TRUE)) {
    stop(sprintf("Plotting requires package 'igraph'."))
  }

  n <- ncol(structure)
  b = diag(0,n)

  if (!(is.null(colors))) {
    if (n != length(colors) && 1 != length(colors)) {
      stop("Incompatible parameters!")
    }
  } else {
    colors <- rep("#88ddff", n)
  }

  for(i in 1:n){
    for(j in 1:n){
      if(sum(structure[,i]*structure[,j])==sum(structure[,i])) b[i,j]=1
    }
  }
  diag(b)<-0
  d <- b
  for(i in 1:n){
    for(j in c(1:n)[-i]){
      if(b[j,i]==1) d[j,]=d[j,]*(1-b[i,])
    }
  }
  ed <- NULL
  for(i in 1:n) for(j in 1:n) if(d[i,j]==1) ed <- c(ed,i,j)
  g1 <- igraph::graph( edges=ed, n=n, directed=TRUE )
  l <- list("0")
  # for(i in 1:n) l[[i]] <- paste(c(c(letters[1:nrow(structure)])[structure[,i]*c(1:nrow(structure))]),collapse = '')
  if (keepNames) {
    l <- lapply(1:n, function(i) {
      paste(c(c(rownames(structure))[structure[,i]*c(1:nrow(structure))]),collapse = itemsep)
    })
  } else {
    l <- lapply(1:n, function(i) {
      paste(c(c(make.unique(letters[(1:nrow(structure))%%26]))[structure[,i]*c(1:nrow(structure))]),collapse = itemsep)
    })
  }
  if (braces)
    l <- as.list(paste0("{",l,"}"))
  igraph::V(g1)$label <- l
  coord = igraph::layout_with_sugiyama(g1)$layout
  if (horizontal) {
    coord <- -coord[,c(2,1)]
  } else {
    coord <- -coord
  }
  igraph::E(g1)$color <- 'black'
  igraph::V(g1)$color <- colors
  if (vertexsize == "fixed")
    vs <- 30
  else if (vertexsize == "variable")
    vs <- 7*ceiling(sqrt(nchar(l)))
  else stop("Undefined vertexsize parameter.")
  if (horizontal) {
    igraph::plot.igraph(g1,layout=coord,
                        vertex.frame.color="white",
                        vertex.shape="ellipse",
                        vertex.size=vs,
                        margin=c(0,0.1,0,0.1)
    )
  } else {
    igraph::plot.igraph(g1,layout=coord,
                        vertex.frame.color="white",
                        vertex.shape="ellipse",
                        vertex.size=1.5*vs,
                        edge.arrow.mode = 0
    )
  }
}

