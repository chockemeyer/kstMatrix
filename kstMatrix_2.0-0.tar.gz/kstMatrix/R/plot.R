#' Plot a Hasse diagram
#'
#' \code{plot} takes a matrix representing a family of sets (knowledge states)
#' or a surmise relation and a color vector, and draws a Hasse diagram.
#' If the color vector is NULL the states are drawn in green, the items in
#' the relation are drawn in orange.
#'
#' @param x Binary matrix representing a family of sets
#' @param ... Optional inherited parameters
#' @param horizontal Boolean defining orientation of the graph, default FALSE
#' @param colors Color value or vector (default NULL; for method="Rgraphviz"
#' only the first element of the vector is used). For the igraph method, hash
#' color codes can be used, for Rgraphviz it must be named colors.
#' @param keepNames Keep item names (default TRUE)
#' @param itemsep Item separator in sets (default ','; only for families
#' of states)
#' @param braces Put braces around vertices (default TRUE; only for
#' families of states)
#' @param method Method to be used for drawing the diagram, "igraph" (default)
#' or "Rgraphviz". For 'Rgraphviz', the packages \code{Rgraphviz}
#' (Bioconductor) and \code{hasseDiagram} (kciomek/hasseDiagram at Github)
#' must be installed.
#' @param igraphvertexsize Size of the vertex objects, "fixed" or "variable"
#' (default "variable"; only for families of states)
#' @param igraphvertexshape Shape of the vertex objects (see
#' [igraph::plot.common], additionally "ellipse" (default)).
#' @param rgraphvizvertexshape Shape of the vertex objects when using Rgraphviz;
#' options are "rect", "roundrect" (default) or "none".
#'
#'
#' @family Plotting knowledge structures
#'
#' @importFrom igraph graph E V plot.igraph add_shape shapes
#' @importFrom plotrix draw.ellipse
#' @importFrom POSetR poset_from_incidence
#'
#' @rdname plot
#' @name plot
#' @export
plot.kmfamset <- function(x,
                          ...,
                          horizontal = FALSE,
                          colors=NULL,
                          keepNames = TRUE,
                          itemsep = ',',
                          braces = TRUE,
                          method = "igraph",
                          igraphvertexsize = "variable",
                          igraphvertexshape = "ellipse",
                          rgraphvizvertexshape = "roundrect"
){
  # The ellipse code was adapted from a stackoverflow posting.
  myellipse <- function(coords, v=NULL, params){
    vertex.size <- params("vertex", "size")/100
    vertex.color <- params("vertex", "color")
    vertex.frame.color <- "black"
    draw.ellipse(x=coords[,1],
                 y=coords[,2],
                 a=vertex.size,
                 b=vertex.size/3,
                 col=vertex.color,
                 border=vertex.frame.color
    )
  }
  add_shape("ellipse",
            clip=shapes("circle")$clip,
            plot=myellipse)



  structure <- t(x)
  if (method == "igraph" && !requireNamespace("igraph", quietly = TRUE)) {
    stop(sprintf("Plotting with method 'igraph' requires package 'igraph' being installed."))
  }
  if (method == "Rgraphviz") {
    if (!requireNamespace("hasseDiagram", quietly = TRUE)) {
      warning("Plotting with method 'Rgraphviz' requires package 'hasseDiagram' bein ginstalled.")
      method <- "igraph"
    }
    if (!requireNamespace("Rgraphviz", quietly = TRUE)) {
      warning("Plotting with method 'Rgraphviz' requires package 'Rgraphviz' being installed.")
      method <- "igraph"
    }
  }

  n <- ncol(structure)
  b = diag(0,n)

  if (!(is.null(colors))) {
    if (n != length(colors) && 1 != length(colors)) {
      stop("Incompatible parameters!")
    }
  } else { # is.null(colors)
    if (method == "igraph") colors <- rep("lightgreen", n)
    else colors <- "black"
  }

  for(i in 1:n){
    for(j in 1:n){
      if(sum(structure[,i]*structure[,j])==sum(structure[,i])) b[i,j]=1
    }
  }
  diag(b)<-0
  d <- b
  for(i in 1:n){
    for(j in c(1:n)[-i]){
      if(b[j,i]==1) d[j,]=d[j,]*(1-b[i,])
    }
  }
  ed <- NULL
  for(i in 1:n) for(j in 1:n) if(d[i,j]==1) ed <- c(ed,i,j)
  g1 <- igraph::make_graph( edges=ed, n=n, directed=TRUE )
  if (keepNames) {
    l <- lapply(1:n, function(i) {
      paste(c(c(rownames(structure))[structure[,i]*c(1:nrow(structure))]),collapse = itemsep)
    })
  } else {
    l <- lapply(1:n, function(i) {
      paste(c(c(make.unique(letters[(1:nrow(structure))%%26]))[structure[,i]*c(1:nrow(structure))]),collapse = itemsep)
    })
  }
  if (braces)
    l <- as.list(paste0("{",l,"}"))
  l <- lapply(l, function(n) {
    if ((n == '') || (n == '{}'))
      '\u2205'
    else
      n
  })

  if (method == "igraph") {
    igraph::V(g1)$label <- l
    coord = igraph::layout_with_sugiyama(g1)$layout
    if (horizontal) {
      coord <- -coord[,c(2,1)]
    } else {
      coord <- -coord
    }
    igraph::E(g1)$color <- 'black'
    igraph::V(g1)$color <- colors

    if (igraphvertexsize == "fixed")
      vs <- 30
    else if (igraphvertexsize == "variable")
      vs <- 7*ceiling(sqrt(nchar(l)))
    else stop("Undefined igraphvertexsize parameter.")
    if (horizontal) {
      igraph::plot.igraph(g1,layout=coord,
                          vertex.size=vs,
                          vertex.shape=igraphvertexshape
      )
    } else {
      igraph::plot.igraph(g1,layout=coord,
                          vertex.size=1.5*vs,
                          vertex.shape=igraphvertexshape,
                          edge.arrow.mode = 0,
                          margin=c(0.1,0,0.1,0),
      )
    }
  } else if (method == "Rgraphviz") {
    if (length(colors) > 1) colors <- colors[1]
    lm <- matrix(as.logical(t(b)), nrow=length(l))
    hasseDiagram::hasse(lm,
                        labels=l,
                        parameters = list(arrow="none",
                                          nodeColor=colors,
                                          shape = rgraphvizvertexshape))
  } else stop(sprintf("Undefined method '%s'.", method))
}




#' @rdname plot
#' @name plot
#' @export
plot.kmsurmiserelation <- function(x,
                                   ...,
                                   horizontal = FALSE,
                                   colors = NULL,
                                   keepNames = TRUE,
                                   method = "igraph",
                                   igraphvertexshape = "circle",
                                   rgraphvizvertexshape = "roundrect"
){
  # The ellipse code was adapted from a stackoverflow posting.
  myellipse <- function(coords, v=NULL, params){
    vertex.size <- params("vertex", "size")/100
    vertex.color <- params("vertex", "color")
    vertex.frame.color <- "black"
    draw.ellipse(x=coords[,1],
                 y=coords[,2],
                 a=vertex.size,
                 b=vertex.size/3,
                 col=vertex.color,
                 border=vertex.frame.color
    )
  }
  add_shape("ellipse",
            clip=shapes("circle")$clip,
            plot=myellipse)



  if (method == "Rgraphviz") {
    if (!requireNamespace("hasseDiagram", quietly = TRUE)) {
      warning("Plotting with method 'Rgraphviz' requires package 'hasseDiagram' bein ginstalled.")
      method <- "igraph"
    }
    if (!requireNamespace("Rgraphviz", quietly = TRUE)) {
      warning("Plotting with method 'Rgraphviz' requires package 'Rgraphviz' being installed.")
      method <- "igraph"
    }
  }
  if (method == "igraph" && !requireNamespace("igraph", quietly = TRUE)) {
    stop(sprintf("Plotting requires package 'igraph'."))
  }

  n <- ncol(x)
  b = diag(0,n)

  if (!(is.null(colors))) {
    if (n != length(colors) && 1 != length(colors)) {
      stop("Incompatible parameters!")
    }
  } else {
    if (method == "igraph") colors <- rep("orange", n)
    else colors = "black"
  }

  for(i in 1:n){
    for(j in 1:n){
      if(sum(x[,i]*x[,j])==sum(x[,i])) b[i,j]=1
    }
  }
  diag(b)<-0
  d <- b
  for(i in 1:n){
    for(j in c(1:n)[-i]){
      if(b[j,i]==1) d[j,]=d[j,]*(1-b[i,])
    }
  }
  ed <- NULL
  for(i in 1:n) for(j in 1:n) if(d[i,j]==1) ed <- c(ed,i,j)
  # l <- as.list(colnames(structure))
  if (keepNames) {
    # l <- lapply(1:n, function(i) {
    #   paste(c(c(colnames(structure))[structure[,i]*c(1:nrow(structure))]),collapse = '')
    # })
    l <- colnames(x)
  } else {
    # l <- lapply(1:n, function(i) {
    #   paste(c(c(make.unique(letters[(1:nrow(structure))%%26]))[structure[,i]*c(1:nrow(structure))]),collapse = '')
    # })
    l <- make.unique(letters[(1:ncol(x))%%26])
  }
  if (method == "igraph") {
    g1 <- igraph::graph( edges=ed, n=n, directed=TRUE )
    igraph::V(g1)$label <- l
    coord = igraph::layout_with_sugiyama(g1)$layout
    if (horizontal) {
      coord <- -coord[,c(2,1)]
    } else {
      coord <- -coord
    }
    igraph::E(g1)$color <- 'black'
    igraph::V(g1)$color <- colors
    if (horizontal) {
      igraph::plot.igraph(g1,
                          layout=coord,
                          vertex.frame.color="black",
                          vetex.shape = igraphvertexshape,
                          vertex.size=20,
                          asp=.6
      )
    } else {
      igraph::plot.igraph(g1,
                          layout=coord,
                          vertex.frame.color="black",
                          vertex.shape = igraphvertexshape,
                          vertex.size=30,
                          edge.arrow.mode = 0,
                          ylim=c(-.8,.8),
                          margin=c(0.15,0,0.15,0)
      )
    }
  }
  else if (method == "Rgraphviz") {
    if (length(colors) > 1) colors <- colors[1]
    lm <- matrix(as.logical(t(b)), nrow=length(l))
    hasseDiagram::hasse(lm,
                        labels=l,
                        parameters = list(arrow="none",
                                          nodeColor=colors,
                                          shape = rgraphvizvertexshape))
  } else stop(sprintf("Undefined method '%s'.", method))

}


