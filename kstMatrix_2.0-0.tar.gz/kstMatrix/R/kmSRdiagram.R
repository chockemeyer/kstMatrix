#' DEPRECATED Plot the Hasse diagram of a basis stored as a matrix
#'
#' \code{kmSRdiagram} takes a matrix representing a surmise relation
#' and a color vector and draws a Hasse diagram. If the color vector is
#' NULL the states are drawn in green.
#'
#' This function is **deprecated** - please use the \code{plot()} method instead.
#'
#' @param structure Binary matrix representing a surmise relation
#' @param horizontal Boolean defining orientation of the graph, default TRUE
#' @param colors Color value or vector (default NULL)
#' @param keepNames Keep item names (default FALSE)
#'
#' @family Deprecated plotting functions
#'
#' @importFrom igraph graph E V plot.igraph
#'
#' @export
kmSRdiagram <- function(structure,
                        horizontal = TRUE,
                        colors = NULL,
                        keepNames = FALSE
){
  if (!requireNamespace("igraph", quietly = TRUE)) {
    stop(sprintf("Plotting requires package 'igraph'."))
  }
  n <- ncol(structure)
  b = diag(0,n)

  if (!(is.null(colors))) {
    if (n != length(colors) && 1 != length(colors)) {
      stop("Incompatible parameters!")
    }
  } else {
    colors <- rep("#eebb99", n)
  }

  for(i in 1:n){
    for(j in 1:n){
      if(sum(structure[,i]*structure[,j])==sum(structure[,i])) b[i,j]=1
    }
  }
  diag(b)<-0
  d <- b
  for(i in 1:n){
    for(j in c(1:n)[-i]){
      if(b[j,i]==1) d[j,]=d[j,]*(1-b[i,])
    }
  }
  ed <- NULL
  for(i in 1:n) for(j in 1:n) if(d[i,j]==1) ed <- c(ed,i,j)
  g1 <- igraph::graph( edges=ed, n=n, directed=TRUE )
  # l <- as.list(colnames(structure))
  if (keepNames) {
    # l <- lapply(1:n, function(i) {
    #   paste(c(c(colnames(structure))[structure[,i]*c(1:nrow(structure))]),collapse = '')
    # })
    l <- colnames(structure)
  } else {
    # l <- lapply(1:n, function(i) {
    #   paste(c(c(make.unique(letters[(1:nrow(structure))%%26]))[structure[,i]*c(1:nrow(structure))]),collapse = '')
    # })
    l <- make.unique(letters[(1:ncol(structure))%%26])
  }
  igraph::V(g1)$label <- l
  coord = igraph::layout_with_sugiyama(g1)$layout
  if (horizontal) {
    coord <- -coord[,c(2,1)]
  } else {
    coord <- -coord
  }
  igraph::E(g1)$color <- 'black'
  igraph::V(g1)$color <- colors
  if (horizontal) {
    igraph::plot.igraph(g1,layout=coord,vertex.frame.color="white",vertex.size=20, asp=.6)
  } else {
    igraph::plot.igraph(g1,layout=coord,vertex.frame.color="white",vertex.size=30, edge.arrow.mode = 0, ylim=c(-.8,.8), margin=c(0.15,0,0.15,0))
  }
}

